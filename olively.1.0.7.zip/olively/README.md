
Olively
===

Olively is a Travel WordPress to help you create the ultimate travel blog. With a modern layout, a dedicated Front Page,

Installation
---------------

### Requirements

`Olively` requires the following dependencies:

- [Latest WordPress Installation](https://wordpress.org/download/)

### Setup

Just Install the Theme from the WordPress Repository.

### Versions

* v1.0
	Initial Upload.
	
* v1.0.1
	Improved the Theme, layout, navigation, search and other changes
	Improved Mobile Layout
	Bug Fixes

* v1.0.2
	More Features
	MailChimp Support
	
* v1.0.3
	Fixed the review errors, Uploading again
	
v 1.0.4
	Added Starter Content
	Fixed errors
	
v 1.0.5
	Fixed a var_dump issue
	Added Front Page
	Removed Front Page Template
	
v1.0.6
	Removed unused code in custom-header.php
	
v1.0.7
	Removed Starter Content

Good luck!
